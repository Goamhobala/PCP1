""" 
generate reports for data analysis
"""

